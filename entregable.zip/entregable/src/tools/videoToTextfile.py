import numpy as np
import cv2
import sys

#########################
# Parametros de entrada.#
#########################
videoFilename = 'funnybaby.avi'
textFilename = 'funnybaby.txt'
salto = 1

if len(sys.argv) == 4:
	videoFilename = sys.argv[1]
	textFilename = sys.argv[2]
	salto = int(sys.argv[3])
elif len(sys.argv) == 3:
	videoFilename = sys.argv[1]
	textFilename = sys.argv[2]
else:
	print "Usage: python videoToTextfile.py <input_video_file> <output_text_file> [salto = 1]"
	sys.exit(1)

# Abrimos archivo de video.
video = cv2.VideoCapture(videoFilename)

# Obtenemos informacion basica.
nFrames = video.get(cv2.cv.CV_CAP_PROP_FRAME_COUNT)
frameRate = video.get(cv2.cv.CV_CAP_PROP_FPS)
height = video.get(cv2.cv.CV_CAP_PROP_FRAME_HEIGHT)
width = video.get(cv2.cv.CV_CAP_PROP_FRAME_WIDTH)

print 'Abriendo archivo: ' + str(video.isOpened())
print 'Info del video:'
print '   # frames:\t' + str(nFrames)
print '   Frame Rate:\t' + str(frameRate)
print '   Height:\t' + str(height)
print '   Width:\t' + str(width)

# Guardamos informacion general en el archivo de salida.
f = open(textFilename,'w')

newFrames = []
# Bajamos al archivo los frames que nos interesan.
for k in xrange(0,int(nFrames),salto):
	ret, frame = video.read()
	if ret:
		grayFrame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
		cv2.imshow('frame',grayFrame)
		newFrames.append(grayFrame)
	k = k+salto
	video.set(cv2.cv.CV_CAP_PROP_POS_FRAMES,k)

# dumpeo informacion del video
f.write(str(len(newFrames)) + '\n')
f.write(str(int(height)) + ',' + str(int(width)) + '\n')
f.write(str(int(frameRate)) + '\n')

# dumpeo frames en escala de grises
for frame in newFrames:
	for i in range(0,int(video.get(4))):
		for j in range(0,int(video.get(3))-1):
			f.write(str(frame[i][j]) + ',')
		f.write(str(frame[i][int(video.get(3)-1)]))
		f.write('\n')

video.release()
cv2.destroyAllWindows()
print 'Fin'
